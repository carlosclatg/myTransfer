module.exports = {
  testEnvironment: "jsdom",
  testMatch: ["**/?(*.)(spec|test).ts?(x)", "**/__tests__/**/*.ts?(x)"],
  moduleNameMapper: {
    ".(css|less|scss)$": "identity-obj-proxy",
  },
};
