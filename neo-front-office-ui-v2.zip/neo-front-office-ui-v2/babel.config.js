// For react testing library
// https://dev.to/alexeagleson/how-to-create-and-publish-a-react-component-library-2oe#adding-tests
module.exports = {
  presets: [
    "@babel/preset-env",
    "@babel/preset-react",
    "@babel/preset-typescript",
  ],
};
