import { addParameters } from "@storybook/react"; // <- or your storybook framework
import "@storybook/addon-console";
import "!style-loader!css-loader!sass-loader!../../src/ReactComponents/scss/main.scss";

import jquery from "jquery";
global.$ = jquery;
global.jQuery = jquery;

addParameters({
  layout: "fullscreen",
  controls: {
    matchers: {
      color: /(background|color)$/i,
      date: /Date$/,
    },
  },
});
