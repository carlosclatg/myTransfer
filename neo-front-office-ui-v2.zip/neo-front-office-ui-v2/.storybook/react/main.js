module.exports = {
  core: {
    builder: "webpack5",
  },
  addons: ["@storybook/addon-essentials", "@storybook/addon-postcss"],
  babel: async (options) => ({
    // Update your babel configuration here
    ...options,
  }),
  framework: "@storybook/react",
  stories: ["../../src/ReactComponents/**/*.stories.@(js|jsx|ts|tsx)"],
  webpackFinal: async (config) => {
    config.module.rules.push({
      test: /\.s[ca]ss$/,
      use: ["style-loader", "css-loader", "postcss-loader", "sass-loader"],
    });
    return config;
  },
};
