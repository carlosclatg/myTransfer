// .storybook/AXATheme.js

import { create } from '@storybook/theming';
import logo from './img/axa.png'

export default create({
    base: 'light',
    brandTitle: 'NEO - AXA Partners',
    brandUrl: '#',
    brandImage: logo,
});