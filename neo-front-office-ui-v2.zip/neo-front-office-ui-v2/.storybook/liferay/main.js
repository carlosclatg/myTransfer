const path = require("path");

module.exports = {
  core: {
    builder: "webpack5",
  },
  output: {
    uniqueName: "liferay-build-mainjs",
  },
  stories: ["../../src/Liferay/**/*.stories.@(js|jsx|ts|tsx)"],
  framework: "@storybook/html",
  addons: [
    "@storybook/addon-postcss",
    "@storybook/addon-viewport/register",
    "@storybook/addon-a11y",
    "@storybook/addon-actions",
    "@storybook/addon-design-assets/register",
    "@storybook/addon-notes/register",
    "@storybook/addon-docs",
    "@storybook/addon-backgrounds",
    {
      name: "@storybook/addon-postcss",
      options: {
        postcssLoaderOptions: {
          implementation: require("postcss"),
        },
      },
    },
    {
      name: "@storybook/preset-scss",
      options: {
        cssLoaderOptions: {
          modules: true,
        },
      },
    },
  ],
  webpackFinal: async (config) => {
    config.module.rules.push({
      test: /\.s[ca]ss$/,
      use: ["style-loader", "css-loader", "postcss-loader", "sass-loader"],
    });
    return config;
  },
};
