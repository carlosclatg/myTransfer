import { addParameters } from "@storybook/html"; // <- or your storybook framework
import "@storybook/addon-console";
import "!style-loader!css-loader!sass-loader!../../src/Liferay/scss/main.scss";

import jquery from "jquery";
global.$ = jquery;
global.jQuery = jquery;

localStorage.clear();

const customViewports = {
  xs: {
    name: 'Extra Small (xs)',
    styles: {
      width: '576px',
      height: '100%',
    },
  },
  sm: {
    name: 'Small (sm)',
    styles: {
      width: '767px',
      height: '100%',
    },
  },
  md: {
    name: 'Medium (md)',
    styles: {
      width: '990px',
      height: '100%',
    },
  },
  xl: {
    name: 'Extra Large (xl)',
    styles: {
      width: '1200px',
      height: '100%',
    },
  },
  xxl: {
    name: 'Extra Extra Large (xxl)',
    styles: {
      width: '1440px',
      height: '100%',
    },
  },
};

addParameters({
  a11y: {
    config: {},
    options: {},
  },
  backgrounds: {
    values: [
      {
        name: "AXA",
        value: "#00008f",
      },
      {
        name: "Grease200",
        value: "#f0f0f0",
      },
    ],
  },
  layout: "fullscreen",
  viewport: {
    viewports: customViewports,
  },
});
