// .storybook/manager.js

import { addons } from '@storybook/addons';
import axaTheme from "./AXATheme";

addons.setConfig({
    theme: axaTheme,
});