# Storybook

[Storybook](https://storybook.js.org/) is an open source tool for building UI components and pages in isolation. It streamlines UI development, testing, and documentation. 

This project has 2 parts: one is from *REACT* and one is from *Liferay* (HTML/SCSS/JS)

## Getting Started

- Install dependencies with `npm install`.
- Run Storybook with `npm run storybook`.


## Arquitecture

```
FRONTENDUI
  ├─ assets                                                      * Statics (images, fonts, js..)
  |    └─ fonts                                                  * Fonts
  |    └─ js                                                     * JS
  ├─ Liferay                                                     * Structure Liferay
  |    └─ components                                             * UI/UX Components
  |    └─ pages                                                  * UI/UX View page
  |    └─ scss                                                   * Styles components (SCSS)
  ├─ ReactComponents                                             *
  |    └─ components                                             *
  └─   └─ scss                                                   *
```

## Generate styles compress and minify (Liferay)
- Run `npm run generate-style:liferay`

## Tests

This repository validates your REACT, HTML, CSS/SCSS and JS code with [HTMLHint](https://htmlhint.com/), [stylelint](https://stylelint.io/) and [ESLint](https://eslint.org/). You can call `npm run test` and/or install editor extensions.

### VSCode extensions

- [HTMLHint extension](https://marketplace.visualstudio.com/items?itemName=ctf0.htmlhint)
- [Stylelint extension](https://marketplace.visualstudio.com/items?itemName=stylelint.vscode-stylelint)
- [ESLint extension](https://marketplace.visualstudio.com/items?itemName=dbaeumer.vscode-eslint)
