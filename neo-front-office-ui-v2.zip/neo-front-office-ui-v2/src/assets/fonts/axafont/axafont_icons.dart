// Place fonts/axafont.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: axafont
//      fonts:
//       - asset: fonts/axafont.ttf
import 'package:flutter/widgets.dart';

class Axafont {
  Axafont._();

  static const String _fontFamily = 'axafont';

  static const IconData star = IconData(0xe924, fontFamily: _fontFamily);
  static const IconData facebook = IconData(0xe91f, fontFamily: _fontFamily);
  static const IconData instagram = IconData(0xe920, fontFamily: _fontFamily);
  static const IconData linkedin = IconData(0xe921, fontFamily: _fontFamily);
  static const IconData twitter = IconData(0xe922, fontFamily: _fontFamily);
  static const IconData youtube = IconData(0xe923, fontFamily: _fontFamily);
  static const IconData group_person = IconData(0xe91c, fontFamily: _fontFamily);
  static const IconData single_person = IconData(0xe91d, fontFamily: _fontFamily);
  static const IconData familiy_person = IconData(0xe91e, fontFamily: _fontFamily);
  static const IconData pdf = IconData(0xe918, fontFamily: _fontFamily);
  static const IconData keys = IconData(0xe91b, fontFamily: _fontFamily);
  static const IconData house = IconData(0xe917, fontFamily: _fontFamily);
  static const IconData tools = IconData(0xe919, fontFamily: _fontFamily);
  static const IconData broken_glass = IconData(0xe91a, fontFamily: _fontFamily);
  static const IconData world = IconData(0xe916, fontFamily: _fontFamily);
  static const IconData info = IconData(0xe900, fontFamily: _fontFamily);
  static const IconData add = IconData(0xe901, fontFamily: _fontFamily);
  static const IconData calendar = IconData(0xe902, fontFamily: _fontFamily);
  static const IconData call = IconData(0xe903, fontFamily: _fontFamily);
  static const IconData check_circle = IconData(0xe904, fontFamily: _fontFamily);
  static const IconData chevron_down = IconData(0xe905, fontFamily: _fontFamily);
  static const IconData close = IconData(0xe906, fontFamily: _fontFamily);
  static const IconData done = IconData(0xe907, fontFamily: _fontFamily);
  static const IconData east = IconData(0xe908, fontFamily: _fontFamily);
  static const IconData email = IconData(0xe909, fontFamily: _fontFamily);
  static const IconData error_outline = IconData(0xe90a, fontFamily: _fontFamily);
  static const IconData error_circle = IconData(0xe90b, fontFamily: _fontFamily);
  static const IconData expand_less = IconData(0xe90c, fontFamily: _fontFamily);
  static const IconData expand_more = IconData(0xe90d, fontFamily: _fontFamily);
  static const IconData file_download = IconData(0xe90e, fontFamily: _fontFamily);
  static const IconData menu = IconData(0xe90f, fontFamily: _fontFamily);
  static const IconData navigate_before = IconData(0xe910, fontFamily: _fontFamily);
  static const IconData navigate_next = IconData(0xe911, fontFamily: _fontFamily);
  static const IconData search = IconData(0xe912, fontFamily: _fontFamily);
  static const IconData share = IconData(0xe913, fontFamily: _fontFamily);
  static const IconData warning = IconData(0xe914, fontFamily: _fontFamily);
  static const IconData west = IconData(0xe915, fontFamily: _fontFamily);
}
