import React, { FunctionComponent } from "react";
import classNames from "classnames";
import Heading from "../../atoms/Heading";
import ProductCard, { Product } from "../../molecules/ProductCard";
import BenefitCard, { Content } from "../../molecules/BenefitCard";
import Documents, { Attachment } from "../../molecules/Documents";
import StepBar from "../../molecules/StepBar";
import Button from "../../atoms/Button";
import Card from "../../atoms/Card";

export interface ProductsProps {
  product: Product;
  content: Content[];
  attachments: Attachment[];
  steps: string[];
  current: number;
  className?: string;
}

const Products: FunctionComponent<ProductsProps> = (props: ProductsProps) => {
  const { product, content, attachments, steps, current, className } = props;
  const commonAttr = {
    className: classNames(className, "products"),
  };

  return (
    <div {...commonAttr}>
      <StepBar steps={steps} current={current} />
      <Heading type="h1" className="text-center font-medium-publicoheadline">
        Buy your home insurance to be covered
      </Heading>
      <Card
        isTransparent
        flex={{
          display: "flex",
          direction: "row",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Button isPrimary>PAY ANNUALLY</Button>
        <Button isPrimaryOutlined>PAY MONTHLY</Button>
      </Card>
      <ProductCard product={product} className="mb-3" />
      <Heading type="h1" className="text-center font-medium-publicoheadline">
        Benefits
      </Heading>
      <BenefitCard content={content} className="mb-3" />
      <Heading type="h1" className="text-center font-medium-publicoheadline">
        Do you want to know more about home insurance?
      </Heading>
      <Documents attachments={attachments} />
    </div>
  );
};

export default Products;
