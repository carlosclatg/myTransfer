import React from "react";

import { Story } from "@storybook/react";
import Component, { ProductsProps } from "./index";

export default {
  title: "React Organisms/Products",
  component: Component,
  parameters: {
    layout: "fullscreen",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    product: {
      benefits: [
        { name: "Windows", icon: "check" },
        { name: "Locks", icon: "check" },
        { name: "Roof", icon: "check" },
        { name: "Pest", icon: "check" },
      ],
      title: "Pay Home Insurance Annually",
      price: "0.00",
    },
    content: [
      {
        icon: "broken-glass",
        title: "Windows",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "keys",
        title: "Locks",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "house",
        title: "Roof",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "tools",
        title: "Pest",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
    ],
    attachments: [
      {
        name: "Document External Same Page",
        content_url: "http://www.africau.edu/images/default/sample.pdf",
        description: "Example document pdf",
        is_terms_and_conditions: false,
        target: "_self",
      },
      {
        name: "Document External New Page",
        content_url: "http://www.africau.edu/images/default/sample.pdf",
        description: "Example document pdf",
        is_terms_and_conditions: false,
        target: "_blank",
      },
    ],
    steps: ["First", "Second", "Third"],
    current: 1,
  },
};

export const Products: Story<ProductsProps> = (args) => <Component {...args} />;
