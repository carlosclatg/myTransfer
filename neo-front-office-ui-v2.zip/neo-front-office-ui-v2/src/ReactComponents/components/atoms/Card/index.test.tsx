import React from "react";
import { render } from "@testing-library/react";

import Card from "./index";

describe("Card", () => {
  test("renders the Card component", () => {
    render(<Card children="Test Card" />);
  });
  test("default card match snapshots", () => {
    const renderCard = render(<Card children="Test Card" />);
    expect(renderCard).toMatchSnapshot();
  });
});
