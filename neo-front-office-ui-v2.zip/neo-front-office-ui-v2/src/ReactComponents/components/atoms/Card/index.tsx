import React, { FunctionComponent } from "react";
import classNames from "classnames";

export interface Flex {
  display?: string;
  justifyContent?: string;
  alignItems?: string;
  direction?: string;
}
export interface CardProps {
  children?: any;
  className?: string;
  flex?: Flex;
  isTransparent?: boolean;
  isClickeable?: boolean;
  onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}

const Card: FunctionComponent<CardProps> = (props: CardProps) => {
  const {
    className,
    children,
    flex,
    isTransparent = false,
    isClickeable = false,
    onClick,
  } = props;
  const commonAttr = {
    className: classNames(
      "m-2",
      className,
      {
        card: !isTransparent,
        "card-transparent": isTransparent,
        "card--click": isClickeable,
      },
      flex?.display && `card--${flex?.display}`,
      flex?.justifyContent && `card--justify-content-${flex?.justifyContent}`,
      flex?.alignItems && `card--align-items-${flex?.alignItems}`,
      flex?.direction && `card--${flex?.direction}`
    ),
  };

  return (
    <div {...commonAttr} {...(isClickeable && { onClick: onClick })}>
      {children}
    </div>
  );
};

export default Card;
