import React from "react";

import { Story } from "@storybook/react";
import Component, { CardProps } from "./index";
import Icon from "../Icon";
import Heading from "../Heading";

const exampleChildren = (
  <div>
    <h1>Title Example</h1>
    <span>
      Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellat,
      molestiae?
    </span>
  </div>
);

export default {
  title: "React Atoms/Card",
  component: Component,
  parameters: {
    layout: "centered",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    name: "card",
    className: "p-3",
    children: exampleChildren,
    isClickeable: false,
    onClick: () => {},
  },
};

export const Card: Story<CardProps> = (args) => (
  <Component {...args}>{args.children}</Component>
);

export const Clickeable: Story<CardProps> = (args) => (
  <Card flex={{ display: "flex", direction: "row" }}>
    <Component {...args}>
      <Icon name="single_person" className="font-superhuge" />
      <Heading type="h2" className="text-center">
        Single
      </Heading>
    </Component>
    <Component {...args}>
      <Icon name="group_person" className="font-superhuge" />
      <Heading type="h2" className="text-center">
        Group
      </Heading>
    </Component>
    <Component {...args}>
      <Icon name="familiy_person" className="font-superhuge" />
      <Heading type="h2" className="text-center">
        Family
      </Heading>
    </Component>
  </Card>
);

Clickeable.args = {
  flex: {
    display: "flex",
    direction: "column",
    justifyContent: "center",
    alignItems: "center",
  },
  isTransparent: true,
  isClickeable: true,
  onClick: () => console.log("clicked <Card></Card>"),
};
