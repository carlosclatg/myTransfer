import React from "react";
import { render } from "@testing-library/react";

import Heading from "./index";

describe("Heading", () => {
  test("renders the Heading component", () => {
    render(<Heading children="Test Heading" />);
  });
  test("default Heading match snapshots", () => {
    const renderHeading = render(<Heading children="Test Heading" />);
    expect(renderHeading).toMatchSnapshot();
  });
});
