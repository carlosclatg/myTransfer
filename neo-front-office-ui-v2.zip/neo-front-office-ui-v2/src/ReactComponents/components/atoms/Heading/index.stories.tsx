import React from "react";

import { Story } from "@storybook/react";
import Component, { HeadingProps } from "./index";

export default {
  title: "React Atoms/Heading",
  component: Component,
  parameters: {
    layout: "centered",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    children: "Default Heading",
    type: "h1",
    className: "",
  },
};

export const Default: Story<HeadingProps> = (args) => <Component {...args} />;

export const h1 = Default.bind({});
export const h2 = Default.bind({});
export const h3 = Default.bind({});
export const h4 = Default.bind({});
export const h5 = Default.bind({});
export const h6 = Default.bind({});

h1.args = {
  type: "h1",
  children: "Heading h1",
  className: "title",
};

h2.args = {
  type: "h2",
  children: "Heading h2",
  className: "title",
};

h3.args = {
  type: "h3",
  children: "Heading h3",
  className: "title",
};

h4.args = {
  type: "h4",
  children: "Heading h4",
  className: "title",
};

h5.args = {
  type: "h5",
  children: "Heading h5",
  className: "title",
};

h6.args = {
  type: "h6",
  children: "Heading h6",
  className: "title",
};
