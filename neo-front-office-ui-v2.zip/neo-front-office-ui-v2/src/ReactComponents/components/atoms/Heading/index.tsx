import React, { FunctionComponent } from "react";
import classNames from "classnames";

export interface HeadingProps {
  type?: string;
  className?: string;
  children?: React.ReactNode;
}

const Heading: FunctionComponent<HeadingProps> = (props: HeadingProps) => {
  const { type, className, children } = props;
  const commonAttr = {
    className: classNames(className, {
      h1: type === "h1",
      h2: type === "h2",
      h3: type === "h3",
      h4: type === "h4",
      h5: type === "h5",
      h6: type === "h6",
    }),
  };
  if (type === "h1") return <h1 {...commonAttr}>{children}</h1>;
  if (type === "h2") return <h2 {...commonAttr}>{children}</h2>;
  if (type === "h3") return <h3 {...commonAttr}>{children}</h3>;
  if (type === "h4") return <h4 {...commonAttr}>{children}</h4>;
  if (type === "h5") return <h5 {...commonAttr}>{children}</h5>;
  if (type === "h6") return <h6 {...commonAttr}>{children}</h6>;

  return <h1 {...commonAttr}>{children}</h1>;
};

export default Heading;
