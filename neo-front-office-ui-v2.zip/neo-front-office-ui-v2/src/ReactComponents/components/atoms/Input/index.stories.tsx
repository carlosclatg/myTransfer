import React from "react";

import { Story } from "@storybook/react";
import Component, { InputProps } from "./index";

export default {
  title: "React Atoms/Input",
  component: Component,
  parameters: {
    layout: "centered",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    name: "input",
    id: "input",
    type: "text",
    className: "input",
    value: null,
    onChange: () => {},
    onFocus: () => {},
    onBlur: () => {},
    required: true,
    error: false,
    disabled: false,
    placeholder: 'Input default'
  },
};

export const Input: Story<InputProps> = (args) => <Component {...args} />;
