import React, { useState, FunctionComponent } from "react";

export interface InputProps {
  name?: string;
  id?: string;
  type?: string;
  className?: string;
  value?: string;
  required?: boolean;
  error?: boolean | "false" | "true" | "grammar" | "spelling";
  disabled?: boolean;
  onChange?: () => void;
  onFocus?: () => void;
  onBlur?: () => void;
  placeholder?: string;
}

const Input: FunctionComponent<InputProps> = (props: InputProps) => {
  const {
    name,
    id,
    type,
    className,
    value,
    onFocus,
    onBlur,
    required,
    error,
    disabled,
    placeholder,
  } = props;

  const [inputValue, setInputValue] = useState(value);

  const handleChange = (value: string) => {
    setInputValue(value);
  };

  return (
    <input
      name={name}
      id={id}
      type={type}
      className={className}
      value={inputValue}
      onChange={(e) => handleChange(e.target.value)}
      required={required}
      onFocus={onFocus}
      onBlur={onBlur}
      aria-invalid={error}
      disabled={disabled}
      {...(placeholder && { placeholder: placeholder })}
    />
  );
};

export default Input;
