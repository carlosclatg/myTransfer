import React from "react";
import { render } from "@testing-library/react";

import Button from "./index";

describe("Button", () => {
  test("renders the Button component", () => {
    render(<Button children="Test button" />);
  });
  test("default button match snapshots", () => {
    const renderButton = render(<Button children="Test Button" />);
    expect(renderButton).toMatchSnapshot();
  });
});
