import React from "react";

import { Story } from "@storybook/react";

// import { boolean, text, withKnobs } from '@storybook/addon-knobs';

import Component, { ButtonProps } from "./index";

// const stories = storiesOf('ReactComponent/Button', module);
// stories.addDecorator(withKnobs);

export default {
  title: "React Atoms/Button",
  component: Component,
  parameters: { layout: "centered" },
  args: {
    disabled: false,
    icon: "",
    iconPosition: "",
    href: "",
    type: "button",
    target: "_self",
    className: "",
    isSmall: false,
    isLarge: false,
    isPrimary: false,
    isSecondary: false,
    isTransparent: false,
    isPrimaryOutlined: false,
    isSecondaryOutlined: false,
    isLight: false,
    isDark: false,
    isExternal: false,
    children: "Default Button",
  },
};

const Template1: Story<ButtonProps> = (args: ButtonProps) => (
  <Component {...args} />
);

export const Default = Template1.bind({});
export const Disabled = Template1.bind({});
export const Primary = Template1.bind({});
export const Secondary = Template1.bind({});
export const Light = Template1.bind({});
export const Dark = Template1.bind({});
export const PrimaryLink = Template1.bind({});
export const SecondaryLink = Template1.bind({});
export const LightLink = Template1.bind({});
export const WithIcon = Template1.bind({});
export const OnlyIcon = Template1.bind({});

Disabled.args = {
  disabled: true,
};

Primary.args = {
  isPrimary: true,
  children: "Primary Button",
};

Secondary.args = {
  isSecondary: true,
  children: "Secondary Button",
};

Light.args = {
  isLight: true,
  children: "Light Button",
};
Dark.args = {
  isDark: true,
  children: "Dark Button",
};

PrimaryLink.args = {
  isPrimary: true,
  isExternal: true,
  children: "Primary Link",
};

SecondaryLink.args = {
  isSecondary: true,
  icon: "east",
  iconPosition: "right",
  isExternal: true,
  children: "Secondary Link",
};

LightLink.args = {
  icon: "east",
  iconPosition: "right",
  isExternal: true,
  isLight: true,
  children: "Light Link",
};

WithIcon.args = {
  icon: "east",
  iconPosition: "right",
  isPrimary: true,
  isExternal: false,
  children: "Primary Icon",
};

OnlyIcon.args = {
  icon: "east",
  iconPosition: "",
  isPrimary: true,
  isExternal: false,
  children: "",
};
