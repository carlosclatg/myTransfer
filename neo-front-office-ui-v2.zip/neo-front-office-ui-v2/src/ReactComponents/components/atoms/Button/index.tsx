import React, { FunctionComponent, useRef } from "react";
import { Link } from "react-router-dom";
import classNames from "classnames";
// import "../../../../Liferay/scss/theme/_buttons.scss";

export interface ButtonProps {
  type?: "button" | "submit" | "reset";
  disabled?: boolean;
  children?: any;
  className?: string;
  isPrimary?: boolean;
  isPrimaryOutlined?: boolean;
  isSecondary?: boolean;
  isSecondaryOutlined?: boolean;
  isSmall?: boolean;
  isLarge?: boolean;
  isLight?: boolean;
  isDark?: boolean;
  isTransparent?: boolean;
  iconPosition?: string;
  isExternal?: boolean;
  target?: "_self" | "_blank" | "_parent" | "_top";
  icon?: string;
  href?: string;
  onClick?: (event: React.MouseEvent<HTMLElement>) => void;
}

const Button: FunctionComponent<ButtonProps> = (props: ButtonProps) => {
  const {
    type = "button",
    isPrimary = false,
    isPrimaryOutlined = false,
    isSecondary = false,
    isSecondaryOutlined = false,
    isLight = false,
    isDark = false,
    isSmall = false,
    isLarge = false,
    isTransparent = false,
    disabled = false,
    onClick,
    className,
    iconPosition = "left",
    icon,
    href,
    isExternal,
    target = "_self",
  } = props;

  const refButton: React.MutableRefObject<HTMLButtonElement | null> =
    useRef(null);

  const commonAttr = {
    onClick,
    onMouseDown: () => {
      refButton.current?.focus();
      refButton.current?.click();
    },
    target: target,
    className: classNames(
      className,
      { btn: !isExternal },
      { link: isExternal },
      { "btn--primary": isPrimary && !isExternal },
      { "btn--secondary": isSecondary && !isExternal },
      { "btn--small": isSmall },
      { "btn--large": isLarge },
      { "btn--ghost": isTransparent },
      { "btn--disabled": disabled },
      { "btn--light-primary": isPrimaryOutlined },
      { "btn--light-secondary": isSecondaryOutlined },
      {
        "btn--light-black":
          isLight &&
          !isPrimary &&
          !isSecondary &&
          !isPrimaryOutlined &&
          !isSecondaryOutlined,
      },
      {
        "btn--light-white":
          isDark &&
          !isPrimary &&
          !isSecondary &&
          !isPrimaryOutlined &&
          !isSecondaryOutlined,
      },
      { "btn--light-primary": isLight && isPrimary },
      { "btn--light-secondary": isLight && isSecondary },
      { "link--primary-link": isExternal && isPrimary },
      { "link--secondary-link": isExternal && isSecondary },
      { "link--light-black": isExternal && !isLight },
      { "link--light-white": isExternal && isLight },
      icon && `icons icons--${icon}`,
      iconPosition && `icons--${iconPosition}`
    ),
  };

  const Markup: FunctionComponent<ButtonProps> = ({ children }) => {
    if (href) {
      if (isExternal) {
        return (
          <a target="_blank" href={href} {...commonAttr}>
            {children}
          </a>
        );
      }
      return (
        <Link to={href} {...commonAttr}>
          {children}
        </Link>
      );
    }
    return (
      <button type={type} disabled={disabled} {...commonAttr} ref={refButton}>
        {children}
      </button>
    );
  };

  return <Markup>{props.children}</Markup>;
};

export default Button;
