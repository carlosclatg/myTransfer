import React, { FunctionComponent } from "react";
import classNames from "classnames";

export interface TextProps {
  type?: string;
  className?: string;
  children?: string | React.ReactNode;
}

const Text: FunctionComponent<TextProps> = (props: TextProps) => {
  const { type, className, children } = props;
  const commonAttr = {
    className: classNames(className, {
      span: type === "span",
    }),
  };
  if (type === "span") return <span {...commonAttr}>{children}</span>;

  return <p {...commonAttr}>{children}</p>;
};

export default Text;
