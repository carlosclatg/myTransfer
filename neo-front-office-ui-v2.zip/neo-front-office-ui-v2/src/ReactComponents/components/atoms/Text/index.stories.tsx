import React from "react";

import { Story } from "@storybook/react";
import Component, { TextProps } from "./index";

export default {
  title: "React Atoms/Text",
  component: Component,
  parameters: {
    layout: "centered",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    children:
      "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente assumenda itaque iure modi rem aliquid dolor sunt facere et accusantium eum nemo magnam veritatis, impedit vitae, commodi numquam quas ex!",
    type: "",
    className: "font-medium",
  },
};

export const Text: Story<TextProps> = (args) => <Component {...args} />;
