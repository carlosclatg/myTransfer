import React from "react";
import { render } from "@testing-library/react";

import Text from "./index";

describe("Text", () => {
  test("renders the Text component", () => {
    render(<Text children="Test Text" />);
  });
  test("default Text match snapshots", () => {
    const renderText = render(<Text children="Test Text" />);
    expect(renderText).toMatchSnapshot();
  });
});
