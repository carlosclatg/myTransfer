import React, { FunctionComponent } from "react";
import classNames from "classnames";

export interface StepProps {
  className?: string;
  index?: number;
  label?: string;
  status?: string;
  total?: number;
}

const Step: FunctionComponent<StepProps> = (props: StepProps) => {
  const { className, index, label, status, total } = props;
  const commonAttr = {
    className: classNames(
      className,
      "step",
      status && `step-${status}`
    ),
  };

  return (
    <div {...commonAttr}>
      <span className="data">Step&nbsp;</span>
      <span className="index">{index + 1}</span>
      <span className="total">&nbsp;/ {total}.&nbsp;</span>
      <span className="label">{label}</span>
    </div>
  );
};

export default Step;
