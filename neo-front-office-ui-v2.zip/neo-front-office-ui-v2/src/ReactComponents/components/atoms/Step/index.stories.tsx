import React from "react";

import { Story } from "@storybook/react";
import Component, { StepProps } from "./index";

export default {
  title: "React Atoms/Step",
  component: Component,
  parameters: {
    layout: "centered",
    backgrounds: {
      default: "dark",
    },
  },
  args: {
    className: "",
    index: 1,
    label: "Second",
    status: "active",
    total: 3,
  },
};

export const Step: Story<StepProps> = (args) => <Component {...args} />;
