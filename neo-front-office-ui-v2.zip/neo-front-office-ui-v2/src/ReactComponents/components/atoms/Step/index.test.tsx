import React from "react";
import { render } from "@testing-library/react";

import Step from "./index";

describe("Step", () => {
  test("renders the Step component", () => {
    render(<Step index={0} label={"First"} />);
  });
  test("default card match snapshots", () => {
    const renderStep = render(<Step index={0} label={"First"} />);
    expect(renderStep).toMatchSnapshot();
  });
});
