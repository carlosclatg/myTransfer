import React from "react";

import { Story } from "@storybook/react";

import Component, { PromoCodeFieldProps } from "./index";

export default {
  title: "React Atoms/Promo Code Field",
  component: Component,
  parameters: { layout: "centered" },
  args: {
    buttonLabel: "ADD PROMO CODE",
    name: "inputPromoCode",
    id: "promoCodeField",
    type: "text",
    className: "input",
    value: "",
    required: true,
    error: false,
    disabled: false,
    placeholder: 'Enter promo code'
  },
};


export const PromoCodeField: Story<PromoCodeFieldProps> = (args) => <Component {...args} />;

