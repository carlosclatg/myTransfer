import React from "react";
import { render, cleanup, fireEvent } from "@testing-library/react";

import PromoCodeField from "./index";

afterAll(cleanup)

describe("PromoCodeField", () => {
  test("renders the PromoCodeField component", () => {
    render(<PromoCodeField buttonLabel="Test PromoCodeField" />);
  });
  test("default PromoCodeField match snapshots", () => {
    const renderPromoCodeField = render(<PromoCodeField buttonLabel="Test PromoCodeField" />);
    expect(renderPromoCodeField).toMatchSnapshot();
  });
});

describe("PromoCodeField before click", () => {
  test("renders the PromoCodeField component", () => {
    const renderPromoCodeField = render(<PromoCodeField buttonLabel="Test PromoCodeField" />);
    const buttonElement = renderPromoCodeField.getByText("Test PromoCodeField")
    expect(buttonElement).toBeTruthy();
    const inputElement = renderPromoCodeField.queryAllByPlaceholderText("Test Placeholder")
    expect(inputElement).toHaveLength(0);
  });
})

describe("PromoCodeField after click", () => {
  test("renders the PromoCodeField component", () => {
    const renderPromoCodeField = render(<PromoCodeField buttonLabel="Test PromoCodeField" placeholder="Test Placeholder"/>);
    const buttonElement = renderPromoCodeField.getByText("Test PromoCodeField")
    fireEvent(
      buttonElement,
      new MouseEvent('click', {
        bubbles: true,
        cancelable: true,
      }),
    )
    const inputElement = renderPromoCodeField.getAllByPlaceholderText("Test Placeholder")
    expect(inputElement).toBeTruthy();
    const buttonElementAfterClick = renderPromoCodeField.queryAllByText("Test PromoCodeField")
    expect(buttonElementAfterClick).toHaveLength(0);
  });
})
