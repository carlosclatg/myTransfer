import React, { useState, FunctionComponent } from "react";

import Button from "../Button";
import Input, { InputProps } from "../Input";

export interface PromoCodeFieldProps extends InputProps {
  buttonLabel?: string;
}

const PromoCodeField: FunctionComponent<PromoCodeFieldProps> = (
  props: PromoCodeFieldProps
) => {
  const {buttonLabel, ...inputFieldProps} = props;
  const [showInputField, setShowInputField] = React.useState(false);

  return (
    <>
      {showInputField ? (
        <Input {...{...inputFieldProps, id:"PromoCodeInputField"}} />
      ) : (
        <Button
          isTransparent
          icon="add"
          iconPosition="left"
          onClick={() => setShowInputField(true)}
        >
          {buttonLabel}
        </Button>
      )}
    </>
  );
};

export default PromoCodeField;
