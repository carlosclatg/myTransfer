import React from "react";

import { Story } from "@storybook/react";
import Component, { IconProps } from "./index";

export default {
  title: "React Atoms/Icon",
  component: Component,
  parameters: {
    layout: "centered",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    name: "west",
    position: "",
    className: "",
  },
};

export const Icon: Story<IconProps> = (args) => <Component {...args} />;
