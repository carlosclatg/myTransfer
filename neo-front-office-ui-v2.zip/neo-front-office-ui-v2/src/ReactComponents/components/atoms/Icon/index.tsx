import React, { FunctionComponent } from "react";
import classNames from "classnames";

export interface IconProps {
  className?: string;
  name?: string;
  position?: string;
  color?: string;
  size?: string;
}

const Icon: FunctionComponent<IconProps> = (props: IconProps) => {
  const { className, name, position, color, size } = props;
  const commonAttr = {
    className: classNames(
      className,
      "icons",
      name && `icons--${name}`,
      position && `icons--${position}`,
      color && `color-${color}`,
      size && `font-${size}`
    ),
  };

  return <i {...commonAttr} />;
};

export default Icon;
