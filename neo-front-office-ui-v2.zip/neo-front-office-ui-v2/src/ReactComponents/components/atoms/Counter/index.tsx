import React, { FunctionComponent, useEffect, useState } from "react";
import classNames from "classnames";

export interface CounterProps {
  className?: string;
  min?: number;
  max?: number;
  reverse?: boolean;
}

const Counter: FunctionComponent<CounterProps> = (props: CounterProps) => {
  const { className, min, max, reverse } = props;
  const commonAttr = {
    className: classNames(className, "counter", reverse && `counter-reverse`),
  };

  const absMin = Math.abs(min) || 0;
  const absMax = Math.abs(max) || 999;

  const [counterValue, setCounterValue] = useState(absMin);

  const handleChangeButtons = (plus: boolean) => {
    if (plus) {
      setCounterValue(counterValue + 1);
    } else {
      setCounterValue(counterValue - 1);
    }
  };

  const handleChangeInput = (value: string) => {
    setCounterValue(parseInt(value) || absMin);
  };

  const checkMinMax = (value: number) => {
    if (absMin > absMax) {
      setCounterValue(0);
    } else if (value < absMin) {
      setCounterValue(absMin);
    } else if (value > absMax) {
      setCounterValue(absMax);
    }
  };

  useEffect(() => {
    checkMinMax(counterValue);
  }, [counterValue]);

  return (
    <div {...commonAttr}>
      <button className="minus" onClick={() => handleChangeButtons(false)}>
        -
      </button>
      <input
        className="value"
        value={counterValue}
        onChange={(e) => handleChangeInput(e.target.value)}
      />
      <button className="plus" onClick={() => handleChangeButtons(true)}>
        +
      </button>
    </div>
  );
};

export default Counter;
