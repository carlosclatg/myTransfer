import React from "react";
import { render } from "@testing-library/react";

import Counter from "./index";

describe("Counter", () => {
  test("renders the Counter component", () => {
    render(<Counter min={0} max={100} />);
  });
  test("default card match snapshots", () => {
    const renderCounter = render(<Counter min={0} max={100} reverse={true} />);
    expect(renderCounter).toMatchSnapshot();
  });
});
