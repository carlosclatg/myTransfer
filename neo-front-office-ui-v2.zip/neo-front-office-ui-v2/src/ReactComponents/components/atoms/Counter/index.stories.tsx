import React from "react";

import { Story } from "@storybook/react";
import Component, { CounterProps } from "./index";

export default {
  title: "React Atoms/Counter",
  component: Component,
  parameters: {
    layout: "centered",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    className: "",
    min: 0,
    max: 100,
  },
};

export const Counter: Story<CounterProps> = (args) => <Component {...args} />;
