import React from "react";
import { render } from "@testing-library/react";

import ProductCard, { Product } from "./index";

const product: Product = {
  price: "0.00",
  title: "My Title",
  benefits: [
    { name: "Windows", icon: "check" },
    { name: "Locks", icon: "check" },
    { name: "Roof", icon: "check" },
    { name: "Pest", icon: "check" },
  ],
};

describe("ProductCard", () => {
  test("renders the ProductCard component", () => {
    render(<ProductCard product={product} />);
  });
  test("default ProductCard match snapshots", () => {
    const renderProductCard = render(<ProductCard product={product} />);
    expect(renderProductCard).toMatchSnapshot();
  });
});
