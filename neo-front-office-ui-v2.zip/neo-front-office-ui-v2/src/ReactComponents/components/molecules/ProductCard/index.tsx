import React, { FunctionComponent } from "react";
import classNames from "classnames";
import Card from "../../atoms/Card";
import Heading from "../../atoms/Heading";
import Text from "../../atoms/Text";
import Button from "../../atoms/Button";
import Icon from "../../atoms/Icon";
export interface Benefit {
  name: string;
  icon: string;
}
export interface Product {
  title: string;
  price: string;
  benefits: Benefit[];
}

export interface ProductCardProps {
  product: Product;
  className?: string;
}

const ProductCard: FunctionComponent<ProductCardProps> = (
  props: ProductCardProps
) => {
  const { product, className } = props;

  return (
    <Card className={className} flex={{ display: "flex" }}>
      <div className="product-card p-3">
        <div className="wrapper-top">
          <Heading
            type="h2"
            className="font-display-5 font-medium-publicoheadline"
          >
            {product.title}
          </Heading>
          <div className="price">
            <Heading type="h1" className="font-semi-bold">
              € {product.price}
            </Heading>
            <Text className="font-small">Per month billed annually</Text>
          </div>
        </div>
        <div className="wrapper-bot">
          <div className="benefits">
            {product?.benefits?.length > 0 &&
              product?.benefits?.map((benefit, index) => (
                <Text key={index} className="font-medium">
                  <>
                    <Icon
                      name={benefit.icon}
                      color="success-lighter"
                      position="left"
                    />
                    {benefit.name}
                  </>
                </Text>
              ))}
          </div>
          <Button isPrimary>BUY HOME INSURANCE</Button>
        </div>
      </div>
    </Card>
  );
};

export default ProductCard;
