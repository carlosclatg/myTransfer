import React from "react";

import { Story } from "@storybook/react";
import Component, { ProductCardProps } from "./index";

export default {
  title: "React Molecules/Product Card",
  component: Component,
  parameters: {
    layout: "fullscreen",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    product: {
      benefits: [
        { name: "Windows", icon: "check" },
        { name: "Locks", icon: "check" },
        { name: "Roof", icon: "check" },
        { name: "Pest", icon: "check" },
      ],
      title: "Pay Home Insurance Annually",
      price: "0.00",
    },
  },
};

export const ProductCard: Story<ProductCardProps> = (args) => (
  <Component {...args} />
);
