import React from "react";

import { Story } from "@storybook/react";
import Component, { StepBarProps } from "./index";

const steps = ["First", "Second", "Third"];

export default {
  title: "React Molecules/Step Bar",
  component: Component,
  parameters: {
    layout: "fullscreen",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    className: "",
    steps: steps,
    current: 1,
  },
};

export const StepBar: Story<StepBarProps> = (args) => <Component {...args} />;
