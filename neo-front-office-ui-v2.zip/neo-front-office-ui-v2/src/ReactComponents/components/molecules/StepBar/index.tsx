import React, { FunctionComponent, useState, useEffect } from "react";
import classNames from "classnames";
import Step from "../../atoms/Step";

export interface StepBarProps {
  className?: string;
  steps?: string[];
  current?: number;
}

const StepBar: FunctionComponent<StepBarProps> = (props: StepBarProps) => {
  const { className, current, steps } = props;
  const commonAttr = {
    className: classNames("stepbar", className),
  };

  const getClassByStatus = (index: number) => {
    let status = "incomplete";
    if (current === index) {
      status = "active";
    } else if (current > index) {
      status = "complete";
    }
    return status;
  };

  return (
    <div {...commonAttr}>
      {steps.map((label, index) => {
        return (
          <Step
            index={index}
            label={label}
            status={getClassByStatus(index)}
            total={steps.length}
            key={index}
          />
        );
      })}
    </div>
  );
};

export default StepBar;
