import React from "react";
import { render } from "@testing-library/react";

import StepBar from "./index";

const steps = ["First", "Second", "Third"];

describe("StepBar", () => {
  test("renders the StepBar component", () => {
    render(<StepBar steps={[]} current={1} />);
  });
  test("default card match snapshots", () => {
    const renderStepBar = render(<StepBar steps={[]} current={1} />);
    expect(renderStepBar).toMatchSnapshot();
  });
});
