import React from "react";
import { render } from "@testing-library/react";

import BenefitCard, { Content } from "./index";

const content: Content[] = [
  {
    icon: "download",
    title: "My Title",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
  },
  {
    icon: "download",
    title: "My Title",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
  },
  {
    icon: "download",
    title: "My Title",
    text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
  },
];

describe("BenefitCard", () => {
  test("renders the BenefitCard component", () => {
    render(<BenefitCard content={content} />);
  });
  test("default BenefitCard match snapshots", () => {
    const renderBenefitCard = render(<BenefitCard content={content} />);
    expect(renderBenefitCard).toMatchSnapshot();
  });
});
