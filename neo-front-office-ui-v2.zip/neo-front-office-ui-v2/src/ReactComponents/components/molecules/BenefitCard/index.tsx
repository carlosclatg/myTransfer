import React, { FunctionComponent } from "react";
import classNames from "classnames";
import Heading from "../../atoms/Heading";
import Text from "../../atoms/Text";
import Icon from "../../atoms/Icon";
import Card from "../../atoms/Card";

export interface Content {
  icon: string;
  title: string;
  text: string;
}

export interface BenefitCardProps {
  content: Content[];
  className?: string;
}

const BenefitCard: FunctionComponent<BenefitCardProps> = (
  props: BenefitCardProps
) => {
  const { content, className } = props;

  return (
    <div className={classNames(className, "benefit-card-container")}>
      {content &&
        content.length > 0 &&
        content.map((benefit, index) => (
          <Card
            flex={{
              display: "flex",
              justifyContent: "center",
              direction: "column",
            }}
            key={index}
            className="benefit-card p-3"
          >
            <div className="head">
              <Icon name={benefit.icon} size="superhuge" color="primary" />
              <Icon
                name="check"
                className="check"
                size="xx-large"
                color="success-lighter"
              />
            </div>
            <Heading
              type="h2"
              className="text-center font-medium-publicoheadline"
            >
              {benefit.title}
            </Heading>
            <Heading type="h3" className="text-center font-display-7">
              {benefit.text}
            </Heading>
          </Card>
        ))}
    </div>
  );
};

export default BenefitCard;
