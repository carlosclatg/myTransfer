import React from "react";

import { Story } from "@storybook/react";
import Component, { BenefitCardProps } from "./index";

export default {
  title: "React Molecules/Benefit Card",
  component: Component,
  parameters: {
    layout: "centered",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    content: [
      {
        icon: "broken-glass",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "tools",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "house",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "pdf",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "download",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "broken-glass",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "keys",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "house",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "download",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "house",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
      {
        icon: "broken-glass",
        title: "My Title",
        text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer ut lorem orci.",
      },
    ],
  },
};

export const BenefitCard: Story<BenefitCardProps> = (args) => (
  <Component {...args} />
);
