import React, { FunctionComponent } from "react";
import classNames from "classnames";
import Button from "../../atoms/Button";
import Card from "../../atoms/Card";
import Heading from "../../atoms/Heading";
import Text from "../../atoms/Text";

export interface Attachment {
  name: string;
  content_url: string;
  description: string;
  is_terms_and_conditions: boolean;
  target: "_self" | "_blank" | "_parent" | "_top";
}

export interface DocumentsProps {
  attachments: Attachment[];
  trackingEvent?(name: string): void;
  className?: string;
}

const Documents: FunctionComponent<DocumentsProps> = (
  props: DocumentsProps
) => {
  const { attachments, trackingEvent, className } = props;
  const commonAttr = {
    className: classNames(className, "p-0"),
    flex: { display: "flex", direction: "column", alignItems: "start" },
  };
  return (
    <>
      {attachments.length > 0 && (
        <Card {...commonAttr}>
          {attachments.map((attachment, index) => {
            return (
              <div className="documents" key={index}>
                <Heading type="h2">{attachment.name}</Heading>
                <Text className="font-small">{attachment.description}</Text>
                <Button
                  isPrimary
                  // tslint:disable:jsx-no-lambda
                  onClick={() => trackingEvent(attachment.name)}
                  href={attachment.content_url}
                  isLarge={true}
                  target={attachment.target}
                  isExternal={true}
                  icon="pdf"
                  iconPosition="left"
                >
                  VIEW FILE
                </Button>
              </div>
            );
          })}
        </Card>
      )}
    </>
  );
};

export default Documents;
