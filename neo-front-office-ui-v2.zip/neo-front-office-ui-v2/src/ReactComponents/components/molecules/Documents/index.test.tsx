import React from "react";
import { render } from "@testing-library/react";

import Documents, { Attachment } from "./index";

const attachments: Attachment[] = [
  {
    name: "Document 1",
    content_url: "http://www.africau.edu/images/default/sample.pdf",
    description: "Example document pdf",
    is_terms_and_conditions: false,
    target: "_self",
  },
  {
    name: "Document 2",
    content_url: "http://www.africau.edu/images/default/sample.pdf",
    description: "Example document pdf",
    is_terms_and_conditions: false,
    target: "_blank",
  },
];

describe("Documents", () => {
  test("renders the Documents component", () => {
    render(<Documents attachments={attachments} />);
  });
  test("default Documents match snapshots", () => {
    const renderDocuments = render(<Documents attachments={attachments} />);
    expect(renderDocuments).toMatchSnapshot();
  });
});
