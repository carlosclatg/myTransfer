import React from "react";

import { Story } from "@storybook/react";
import Component, { DocumentsProps } from "./index";

export default {
  title: "React Molecules/Documents",
  component: Component,
  parameters: {
    layout: "fullscreen",
    backgrounds: {
      default: "light",
    },
  },
  args: {
    attachments: [
      {
        name: "Document Example 1",
        content_url: "http://www.africau.edu/images/default/sample.pdf",
        description: "Example document pdf",
        is_terms_and_conditions: false,
        target: "_self",
      },
      {
        name: "Document Example 2",
        content_url: "http://www.africau.edu/images/default/sample.pdf",
        description: "Example document pdf",
        is_terms_and_conditions: false,
        target: "_blank",
      },
    ],
  },
};

export const Documents: Story<DocumentsProps> = (args) => (
  <div style={{ padding: "1em" }}>
    <Component {...args} />
  </div>
);
