import "./insurance.scss";
import insurance from "./insurance.html";

export default {
  title: "Components/Insurance",
  parameters: { },
};

export const insurances = () => insurance;