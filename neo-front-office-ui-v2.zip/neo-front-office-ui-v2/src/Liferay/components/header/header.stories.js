import "./header.scss";
import header from "./header.html";

export default {
  title: "Components/Header",
  parameters: { },
};

export const Headers = () => header;

