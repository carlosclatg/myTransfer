import "./quote.scss";
import quote from "./quote.html";
export default {
  title: "Components/Quote",
  parameters: { },
};

export const Quotes = () => quote;
