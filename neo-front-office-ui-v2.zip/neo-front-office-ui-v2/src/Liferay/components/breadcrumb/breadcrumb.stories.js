import "./breadcrumb.scss";
import breadcrumb from "./breadcrumb.html";

export default {
  title: "Components/Breadcrumb",
  parameters: { layout: "centered" },
};

export const Breadcrumbs = () => breadcrumb;

