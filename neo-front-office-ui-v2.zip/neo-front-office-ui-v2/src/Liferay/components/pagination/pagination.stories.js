import "./pagination.scss";
import pagination from "./pagination.html";

export default {
  title: "Components/Pagination",
  parameters: { layout: "centered" },
};

export const Paginations = () => pagination;

