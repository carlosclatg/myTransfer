import "./forms.scss";
import form from "./forms.html";
import checkbox from "./checkboxs/checkbox.html";
import radiobutton from "./radiobuttons/radiobutton.html";
import toggleswitch from "./toggleswitches/toggle_switches.html";
import slidercontrol from "./slider_controls/slider_controls.html";
import inputgroup from "./inputgroup/inputgroup.html";

export default {
  title: "Components/Forms",
  parameters: {},
};

export const Inputs = () => form;
export const checkboxs = () => checkbox;
export const radiobuttons = () => radiobutton;
export const Slider_control = () => slidercontrol;
export const Input_group = () => inputgroup;

const toggle = () => toggleswitch;
export const toggleSwitch = toggle.bind({});
toggleSwitch.parameters = {
  layout: "centered",
};
