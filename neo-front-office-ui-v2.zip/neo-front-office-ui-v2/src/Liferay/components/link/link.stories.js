import link from "./link.html";

export default {
  title: "Components/Link",
  parameters: { layout: "centered" },
};

export const links = () => link;

