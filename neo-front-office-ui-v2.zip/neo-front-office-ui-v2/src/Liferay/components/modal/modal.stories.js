import "./modal.scss";
import modal from "./modal.html";

export default {
  title: "Components/Modal",
  parameters: { layout: "centered" },
};

export const Modals = () => modal;

