import "./footer-small.scss";
import footerSmall from "./footer-small.html";
import "./footer.scss";
import footers from "./footer.html";
import footerDesktop from "./footer-desktop.html";

export default {
  title: "Components/Footers",
  parameters: { },
};

export const FooterNormal = () => footers;
export const FooterSmall = () => footerSmall;
export const FooterDesktop = () => footerDesktop;
