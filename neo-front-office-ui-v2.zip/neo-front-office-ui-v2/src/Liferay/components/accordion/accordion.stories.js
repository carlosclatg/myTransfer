import "./accordion.scss";
import accordion from "./accordion.html";

export default {
  title: "Components/Accordion",
  parameters: { },
};

export const Accordions = () => accordion;

