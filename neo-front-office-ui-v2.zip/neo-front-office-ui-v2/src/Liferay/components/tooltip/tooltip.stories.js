import "./tooltip.scss";
import tooltip from "./tooltip.html";
export default {
  title: "Components/Tooltip",
  parameters: { layout: "centered" },
};

export const Tooltips = () => tooltip;
