import "./nav.scss";
import nav from "./nav.html";

export default {
  title: "Components/Nav",
  parameters: { },
};

export const Navs = () => nav;

