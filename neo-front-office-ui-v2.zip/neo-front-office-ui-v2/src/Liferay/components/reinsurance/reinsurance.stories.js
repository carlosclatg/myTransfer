import "./reinsurance.scss";
import reinsurance from "./reinsurance.html";
import information from "./information.html";

export default {
  title: "Components/Reinsurance",
  parameters: {},
};

export const Reinsurance = () => reinsurance;

const Template = (args) => information;

export const Information = Template.bind({});
Information.parameters = {
  backgrounds: {
    default: 'Grease200'
  }
};