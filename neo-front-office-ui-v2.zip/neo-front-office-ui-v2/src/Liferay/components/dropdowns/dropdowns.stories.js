import "./dropdowns.scss";
import dropdown from "./dropdowns.html";

export default {
  title: "Components/Dropdown",
  parameters: { layout: "centered" },
};

export const Dropdowns = () => dropdown;

