import "./typography.scss";
import typography from "./typography.html";

export default {
  title: "Components/Typography",
  parameters: { layout: "centered" },
};

export const headers = () => typography;
