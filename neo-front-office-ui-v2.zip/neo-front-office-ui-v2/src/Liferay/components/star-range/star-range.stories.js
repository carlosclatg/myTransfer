import "./star-range.scss";
import starRange from "./star-range.html";

export default {
  title: "Components/Range Start",
  parameters: { },
};

export const RangeStars = () => starRange;

