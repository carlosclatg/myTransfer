import "./carrousel.scss";
import carrousel_center from "./carrousel_center.html";
import carrousel_end from "./carrousel_end.html";

export default {
  title: "Components/Carrousel",
  parameters: { },
};

export const CarouselCenter = () => carrousel_center;
export const CarouselEnd = () => carrousel_end;

