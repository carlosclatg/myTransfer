import "./keys.scss";
import key from "./keys.html";

export default {
  title: "Components/Key",
  parameters: { },
};

export const Keys = () => key;

