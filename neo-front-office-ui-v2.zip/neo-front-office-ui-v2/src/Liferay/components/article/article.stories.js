import "./article.scss";
import articleblock from "./article.html";
import articleinline from "./articles.html";

export default {
  title: "Components/Article Block Cards",
  parameters: { },
};

export const Article_block = () => articleblock;
export const Article_inline = () => articleinline;