import "./collapse.scss";
import collapse from "./collapse.html";

export default {
  title: "Components/Collapse",
  parameters: { },
};

export const Collapses = () => collapse;

