import "./subscribe.scss";
import subscribe from "./subscribe.html";

export default {
  title: "Components/Subscribes",
  parameters: { },
};

export const Subscribe = () => subscribe;

