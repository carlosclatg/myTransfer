import primary from "./primary.html";
import secondary from "./secondary.html";
import otherButtons from "./other_buttons.html";
import outlineButton from "./buttons_outline.html";

export default {
  title: "Components/Button",
  parameters: { layout: "centered" },
};

export const Primary = () => primary;
export const Secondary = () => secondary;
export const OutlineButton = () => outlineButton;

const Template = (args) => otherButtons;

export const OtherButton = Template.bind({});
OtherButton.parameters = {
  backgrounds: {
    default: 'AXA'
  }
};