import "./faqs.scss";
import faq from "./faqs.html";

export default { title: "Pages/Faqs" };

export const basic = () => faq;
