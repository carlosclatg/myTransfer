import "./home.scss";
import home from "./home.html";

export default { title: "Pages/Home" };

export const basic = () => home;
