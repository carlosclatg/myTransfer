import "./contact.scss";
import contact from "./contact.html";

export default { title: "Pages/Contact" };

export const FormContact = () => contact;
