// STYLES GLOBAL //
import "./scss/main.scss";
// STYLES GLOBAL //

// Components //
import "./components/accordion/accordion.scss";
import "./components/article/article.scss";
import "./components/breadcrumb/breadcrumb.scss";
import "./components/button/button.scss";
import "./components/collapse/collapse.scss";
import "./components/forms/forms.scss";
import "./components/header/header.scss";
import "./components/insurance/insurance.scss";
import "./components/link/link.scss";
import "./components/modal/modal.scss";
import "./components/nav/nav.scss";
import "./components/pagination/pagination.scss";
import "./components/quote/quote.scss";
import "./components/reinsurance/reinsurance.scss";
import "./components/subscribe/subscribe.scss";
import "./components/tooltip/tooltip.scss";
import "./components/typography/typography.scss";
import "./components/star-range/star-range.scss";
import "./components/keys/keys.scss";
// Components //