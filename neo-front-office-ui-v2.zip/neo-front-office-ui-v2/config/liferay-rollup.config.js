import scss from 'rollup-plugin-scss';
import copy from 'rollup-plugin-copy'

export default {
  input: "src/Liferay/create-min-styles.js",
  plugins: [
    // Generate SCSS to CSS compress
    scss({
      include: ["/**/*.css", "/**/*.scss", "/**/*.sass"],
      output: 'dist/cms/css/neo-v2.css',
      outputStyle: "compressed",
      verbose: true,
      processor: (css, map) => ({
        css: css.replaceAll('../../assets/', '../'), map
      })
    }),
    copy({
      targets: [
        // Copy Fonts
        {
          src: [
            'src/assets/fonts/sourcesanspro/',
            'src/assets/fonts/publicoheadline/'],
          dest: 'dist/cms/fonts'
        },
        // Copy Fonts
        {
          src: [
            'src/assets/fonts/axafont/fonts/*'],
          dest: 'dist/cms/fonts/axafont/fonts'
        },
        // Copy images
        {
          src: [
            'src/assets/images/common-axa/*'],
          dest: 'dist/cms/images/common-axa'
        },
        // Copy JS
        {
          src: [
            'src/assets/js/*'],
          dest: 'dist/cms/js'
        },
      ],
    })
  ],
};
