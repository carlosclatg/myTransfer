import peerDepsExternal from "rollup-plugin-peer-deps-external";
import resolve from "@rollup/plugin-node-resolve";
import commonjs from "@rollup/plugin-commonjs";
import typescript from "rollup-plugin-typescript2";
import copy from "rollup-plugin-copy";
import cleaner from "rollup-plugin-cleaner";
const packageJson = require("../package.json");
import scss from "rollup-plugin-scss";

export default {
  input: "src/ReactComponents/index.ts",
  output: [
    {
      file: packageJson.main,
      format: "cjs",
      sourcemap: true,
    },
    {
      file: packageJson.module,
      format: "esm",
      sourcemap: true,
    },
  ],
  plugins: [
    cleaner({
      targets: ["./build/"],
    }),
    peerDepsExternal(),
    typescript({ useTsconfigDeclarationDir: true }),
    commonjs(),
    scss({
      include: ["/**/*.css", "/**/*.scss", "/**/*.sass"],
      output: "build/styles/index.css",
      outputStyle: "compressed",
      verbose: true,
    }),
    copy({
      targets: [{ src: "src/assets/*", dest: "build/assets/" }],
    }),
    resolve(),
  ],
};
